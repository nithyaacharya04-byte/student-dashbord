# Student-Performance-Excel-Dashboard
Student performance accross different areas in relation to certain factors explained using powerpoint and excel
